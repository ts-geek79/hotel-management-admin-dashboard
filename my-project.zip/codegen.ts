import type { CodegenConfig } from "@graphql-codegen/cli";

const config: CodegenConfig = {
  schema: "http://localhost:5000/graphql",
  documents: ["src/**/*.graphql", "!src/gql/**"],
  generates: {
  "./src/gql/graphql.ts": { 
      plugins: [
      "typescript",
      "typescript-operations", 
      "typescript-react-apollo"
    ],
    config: {
      useTypeImports: true,
      withHooks: true,
    }
  }
}
};

export default config;